This folder contains the data set for COVID Data Exploration Portfolio Project.

Below are the steps that I went through before importing the data file to SQL Server Management Studio.

This README serves as 'documentation' of some sort to keep track on the things that I did while doing this project.

The Steps:

1. OPTIONAL: This is personal preference, but I like to make the columns of the excel worksheet file not overlap into each other; so to auto-size the columns, I just select all the headers of each column and double click the left/right border of any of the selected header of any column. Also, apply Filter to each of the columns. (Filter is found under Data section) 

2. Look for Population Column, as this column is pretty relevant to the project, and place it between Column D and Column E. We need to split the data file into two and name them COVID_Deaths_Data and COVID_Vaccinations_Data respectively. COVID_Deaths_Data will contain data concerning about cases of COVID casualties/deaths whereas COVID_Vaccinations_Data will contain data that concerns COVID vaccination cases.

From columns AA up to the very last column is for COVID_Vaccinations_Data, columns F to Z is for COVID_Deaths_Data. Create copies of the data set accordingly.

3. Save the files in .csv format

The data set is now ready to be imported to SQL Server Management Studio


